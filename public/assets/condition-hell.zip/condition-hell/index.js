// node .index.js to run program

const operations = new Map();

for (let i = 1; i <= 4; i++) {
    operations.set(`operation${i}`, () => `operation${i + 1} success!`);
    // operations.set(`operation${i}`, () => false);
}

const pass = fn => fn;

// 1) Solution One
function oprationFailHandler() {
    let error = null;

    if (!pass(operations.get('operation1')())) return error = 'operation1failed';
    if (!pass(operations.get('operation2')())) return error = 'operation2failed';
    if (!pass(operations.get('operation3')())) return error = 'operation3failed';
    if (!pass(operations.get('operation4')())) return error = 'operation4failed';
    return error = 'no error';
}

// 2) Solution Two
function operationFailHandlerSecond() {
    let error = null;
    for(let i = 1; i <= operations.size; i++){
        if(!pass(operations.get(`operation${i}`)())) return error = `operation${i}failed`;
    }
    return error = 'no error';
}

console.log(oprationFailHandler());
console.log(operationFailHandlerSecond());