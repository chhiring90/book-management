const crypto = require('crypto');

const generateSalt = (rounds = 12) => {
    if (rounds >= 15) throw new Error(`Rounds must be less than 15 `);
    if (typeof rounds !== 'number') throw new Error('Rounds must be a number');
    return crypto
    .randomBytes(Math.ceil(rounds / 2))
    .toString('hex')
    .slice(0, rounds);
}

const hasher = (password, salt) => {
    const hash = crypto
        .createHmac('sha512', salt)
        .update(password)
        .digest('hex');

    return {
        hash,
        salt,
        password
    }
}

const result = hasher('test1234', generateSalt());
console.log(result);