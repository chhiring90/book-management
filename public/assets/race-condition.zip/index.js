let mutex = Promise.resolve();

const randomDelay = () => new Promise(resolve => {
    setTimeout(resolve, Math.random() * 100);
});

let balance = 0;

async function loadBalance() {
    await randomDelay();
    return balance;
}

async function saveBalance(value) {
    await randomDelay();
    balance = value;
}

async function sellChocolate() {
    mutex = mutex.then(async () => {
        const balance = await loadBalance();
        console.log(`sellChocolate - balance loaded: ${balance}`);
        const newBalance = balance + 50;
        await saveBalance(newBalance);
        console.log(`sellChocolate - balance updated: ${newBalance}`);
    }).catch((err) => console.log(err.message));
    return mutex;
}

async function sellCookies() {
    mutex = mutex.then(async () => {
        const balance = await loadBalance();
        console.log(`sellCookies - balance loaded: ${balance}`);
        const newBalance = balance + 50;
        await saveBalance(newBalance);
        console.log(`sellCookies - balance updated: ${newBalance}`);
    }).catch((err) => console.log(err.message));
    return mutex;
}

async function main() {
    // no await will doesnot stop the transition2
    // 1)It will cause race condition
    // const transition1 = sellChocolate();
    // const transition2 = sellCookies();

    // await transition1;
    // await transition2;

    // Promise.all([sellChocolate(), sellCookies()]);

    // 2)General race condition fixes
    // await sellChocolate();
    // await sellCookies();

    // 3) Complex race condition
    await Promise.all([
        sellChocolate(),
        sellCookies(),
        sellChocolate(),
        sellCookies(),
        sellChocolate(),
        sellCookies(),
    ]);


    const balance = await loadBalance();
    console.log(`Final balance: ${balance}`)
}

main();