exports.perimeter = (length, breadth) => {
    if (!length || !breadth) {
        return 'undefined';
    }
    if (typeof length !== 'number') {
        return 'length is Not a number';
    }
    if (typeof breadth !== 'number') {
        return 'breadth is Not a number';
    }
    if (length < 0 || breadth < 0) {
        return ('dimension cannot be negatives');
    }
    return 2 * (length + breadth);
}