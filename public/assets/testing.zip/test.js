const assert = require('assert');
const { perimeter } = require('.');

describe('perimeter', function () {
    it('should return number when value is positive number', function () {
        assert.equal(perimeter(2,3), 10);
    });
    it('should return undefined when values are not passed in arguments', function () {
        assert.equal(perimeter(), 'undefined');
    });
    it('should ask for length as a number', function () {
        assert.equal(perimeter('15', 10), 'length is Not a number');
    });
    it('should ask for breadth as a number', function () {
        assert.equal(perimeter(15, '10'), 'breadth is Not a number');
    });
    it('should ask for positive number when value is negative', function () {
        assert.equal(perimeter(-15, -10), 'dimension cannot be negatives');
    });
});